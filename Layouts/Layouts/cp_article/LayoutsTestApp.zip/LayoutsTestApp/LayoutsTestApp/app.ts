﻿/// <reference path="layouts.d.ts"/>

//window.onload = () => {
//    var app = new layouts.Application();
//    var lmlReader = new layouts.XamlReader();

//    var lmlTest = `<?xml version="1.0" encoding="utf-8" ?>
//<Page>
//    <TextBlock id="helloworld" Text="Hello World" VerticalAlignment="Center" HorizontalAlignment="Center"/>
//</Page>
//`;
//    app.page = lmlReader.Parse(lmlTest);
//};

//window.onload = () => {
//    var app = new layouts.Application();
//    var lmlReader = new layouts.XamlReader();

//    var lmlTest = `<?xml version= "1.0" encoding= "utf-8" ?>
//<Stack Orientation="Vertical" VerticalAlignment= "Center" HorizontalAlignment= "Center" >
//    <TextBlock Text="Welcome to Login Page" Margin= "8" />
//    <TextBox Placeholder= "User name" Margin= "8" />
//    <TextBox Type= "password" Placeholder= "Password" Margin= "8" />
//    <Button Text="Sign In" Margin= "8,16,8,8" />
//</Stack>
//`;
//    app.page = lmlReader.Parse(lmlTest);
//};

//window.onload = () => {
//    var app = new layouts.Application();
//    var lmlReader = new layouts.XamlReader();

//    var lmlTest = `<?xml version= "1.0" encoding= "utf-8" ?>
//<Stack Orientation="Vertical" VerticalAlignment= "Center" HorizontalAlignment= "Center">
//    <TextBlock Text="Welcome to Login Page" Margin= "8" />
//    <TextBox Placeholder= "User name" Margin= "8" />
//    <TextBox Type= "password" Placeholder= "Password" Margin= "8" />
//    <Grid Columns="* Auto" Margin= "8,16,8,8" MaxWidth="300">
//        <Button Text="Sign In"/>
//        <TextBlock Text="Not yet registered?" Grid.Column="1" Margin="10,0,0,0"/>
//    </Grid>
//</Stack>
//`;
//    app.page = lmlReader.Parse(lmlTest);
//};

class LoginViewModel extends layouts.DepObject {
    static typeName: string = "app.LoginViewModel";
    get typeName(): string {
        return LoginViewModel.typeName;
    }

    constructor() {
        super();
    }

    private _username: string;
    get username(): string {
        return this._username;
    }
    set username(value: string) {
        if (this._username != value) {
            var oldValue = this._username;
            this._username = value;
            this.onPropertyChanged("username", value, oldValue);
            this._loginCommand.canExecuteChanged();
        }
    }

    private _password: string;
    get password(): string {
        return this._password;
    }
    set password(value: string) {
        if (this._password != value) {
            var oldValue = this._password;
            this._password = value;
            this.onPropertyChanged("password", value, oldValue);
            this._loginCommand.canExecuteChanged();
        }
    }

    private _loginCommand: layouts.Command;
    get loginCommand(): layouts.Command {
        if (this._loginCommand == null)
            this._loginCommand = new layouts.Command((cmd, p) => this.onLogin(), (cmd, p) => this.canLogin());
        return this._loginCommand;
    }

    onLogin() {
        if (this._username == "test" &&
            this._password == "test") {
            alert("Logged in!");
        }
        else
            alert("Unable to login!");
    }

    canLogin(): boolean {
        return this._username != null && this._username.trim().length > 0 &&
            this._password != null && this._password.trim().length > 0;
    }

}

window.onload = () => {
    var app = new layouts.Application();
    var lmlReader = new layouts.XamlReader();

    var lmlTest = `<?xml version= "1.0" encoding= "utf-8" ?>
<Stack Orientation="Vertical" VerticalAlignment="Center" HorizontalAlignment="Center">
    <TextBlock Text="Welcome to Login Page" Margin="8"/>
    <TextBox Text="{path:username,mode:twoway}" Placeholder="User name (test)" Margin="8"/>
    <TextBox Text="{path:password,mode:twoway}" Type="password" Placeholder="Password (test)" Margin="8"/>
    <Button Text="Sign In" Command="{path:loginCommand}" Margin="8,16,8,8"/>
</Stack>
`;
    app.page = lmlReader.Parse(lmlTest);
    app.page.dataContext = new LoginViewModel();
};

//window.onload = () => {
//    var app = new layouts.Application();
//    var page = new layouts.controls.Page();
//    var textBlock = new layouts.controls.TextBlock();
//    textBlock.text = "Hello World!";
//    textBlock.verticalAlignment = layouts.VerticalAlignment.Center;
//    textBlock.horizontalAlignment = layouts.HorizontalAlignment.Center;
//    page.child = textBlock;
//    app.page = page;
//};