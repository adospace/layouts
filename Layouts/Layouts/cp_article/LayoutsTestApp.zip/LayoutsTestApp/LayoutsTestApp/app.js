/// <reference path="layouts.d.ts"/>
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
//window.onload = () => {
//    var app = new layouts.Application();
//    var lmlReader = new layouts.XamlReader();
//    var lmlTest = `<?xml version="1.0" encoding="utf-8" ?>
//<Page>
//    <TextBlock id="helloworld" Text="Hello World" VerticalAlignment="Center" HorizontalAlignment="Center"/>
//</Page>
//`;
//    app.page = lmlReader.Parse(lmlTest);
//};
//window.onload = () => {
//    var app = new layouts.Application();
//    var lmlReader = new layouts.XamlReader();
//    var lmlTest = `<?xml version= "1.0" encoding= "utf-8" ?>
//<Stack Orientation="Vertical" VerticalAlignment= "Center" HorizontalAlignment= "Center" >
//    <TextBlock Text="Welcome to Login Page" Margin= "8" />
//    <TextBox Placeholder= "User name" Margin= "8" />
//    <TextBox Type= "password" Placeholder= "Password" Margin= "8" />
//    <Button Text="Sign In" Margin= "8,16,8,8" />
//</Stack>
//`;
//    app.page = lmlReader.Parse(lmlTest);
//};
//window.onload = () => {
//    var app = new layouts.Application();
//    var lmlReader = new layouts.XamlReader();
//    var lmlTest = `<?xml version= "1.0" encoding= "utf-8" ?>
//<Stack Orientation="Vertical" VerticalAlignment= "Center" HorizontalAlignment= "Center">
//    <TextBlock Text="Welcome to Login Page" Margin= "8" />
//    <TextBox Placeholder= "User name" Margin= "8" />
//    <TextBox Type= "password" Placeholder= "Password" Margin= "8" />
//    <Grid Columns="* Auto" Margin= "8,16,8,8" MaxWidth="300">
//        <Button Text="Sign In"/>
//        <TextBlock Text="Not yet registered?" Grid.Column="1" Margin="10,0,0,0"/>
//    </Grid>
//</Stack>
//`;
//    app.page = lmlReader.Parse(lmlTest);
//};
var LoginViewModel = (function (_super) {
    __extends(LoginViewModel, _super);
    function LoginViewModel() {
        _super.call(this);
    }
    Object.defineProperty(LoginViewModel.prototype, "typeName", {
        get: function () {
            return LoginViewModel.typeName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(LoginViewModel.prototype, "username", {
        get: function () {
            return this._username;
        },
        set: function (value) {
            if (this._username != value) {
                var oldValue = this._username;
                this._username = value;
                this.onPropertyChanged("username", value, oldValue);
                this._loginCommand.canExecuteChanged();
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(LoginViewModel.prototype, "password", {
        get: function () {
            return this._password;
        },
        set: function (value) {
            if (this._password != value) {
                var oldValue = this._password;
                this._password = value;
                this.onPropertyChanged("password", value, oldValue);
                this._loginCommand.canExecuteChanged();
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(LoginViewModel.prototype, "loginCommand", {
        get: function () {
            var _this = this;
            if (this._loginCommand == null)
                this._loginCommand = new layouts.Command(function (cmd, p) { return _this.onLogin(); }, function (cmd, p) { return _this.canLogin(); });
            return this._loginCommand;
        },
        enumerable: true,
        configurable: true
    });
    LoginViewModel.prototype.onLogin = function () {
        if (this._username == "test" &&
            this._password == "test") {
            alert("Logged in!");
        }
        else
            alert("Unable to login!");
    };
    LoginViewModel.prototype.canLogin = function () {
        return this._username != null && this._username.trim().length > 0 &&
            this._password != null && this._password.trim().length > 0;
    };
    LoginViewModel.typeName = "app.LoginViewModel";
    return LoginViewModel;
})(layouts.DepObject);
window.onload = function () {
    var app = new layouts.Application();
    var lmlReader = new layouts.XamlReader();
    var lmlTest = "<?xml version= \"1.0\" encoding= \"utf-8\" ?>\n<Stack Orientation=\"Vertical\" VerticalAlignment=\"Center\" HorizontalAlignment=\"Center\">\n    <TextBlock Text=\"Welcome to Login Page\" Margin=\"8\"/>\n    <TextBox Text=\"{path:username,mode:twoway}\" Placeholder=\"User name (test)\" Margin=\"8\"/>\n    <TextBox Text=\"{path:password,mode:twoway}\" Type=\"password\" Placeholder=\"Password (test)\" Margin=\"8\"/>\n    <Button Text=\"Sign In\" Command=\"{path:loginCommand}\" Margin=\"8,16,8,8\"/>\n</Stack>\n";
    app.page = lmlReader.Parse(lmlTest);
    app.page.dataContext = new LoginViewModel();
};
//window.onload = () => {
//    var app = new layouts.Application();
//    var page = new layouts.controls.Page();
//    var textBlock = new layouts.controls.TextBlock();
//    textBlock.text = "Hello World!";
//    textBlock.verticalAlignment = layouts.VerticalAlignment.Center;
//    textBlock.horizontalAlignment = layouts.HorizontalAlignment.Center;
//    page.child = textBlock;
//    app.page = page;
//}; 
//# sourceMappingURL=app.js.map